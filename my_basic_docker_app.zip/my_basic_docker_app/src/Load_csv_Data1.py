# Import knihovny pro práci s daty (tabulkami)
import pandas as pd
# Nástroj pro komunikaci s operačním systémem
import os
# Časové funkce
import time
# Nástroj pro vytvoření spojení s databází
from sqlalchemy import create_engine

# Cesta k souboru (v Dockeru v /app/)
file_path = '/app/src/Data1.csv'
# Tisk pro kontrolu, že skript začíná běžet
print("Spouštím ETL proces...")

#1. ČÁST: Načtení a úprava dat (Extract & Transform)
try:
    # Načte CSV: sep=r'\s+' (oddělovač je jedna nebo více mezer), encoding='utf-16' (kódování souboru)
    # names=[...] definuje názvy sloupců
    df = pd.read_csv(file_path, sep=r'\s+', header=None, encoding='utf-16', 
                     names=['Datum', 'Cas', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6'])
    # Spojí sloupec Datum a Čas do jednoho a převede ho na formát času (Timestamp)
    df['Timestamp'] = pd.to_datetime(df['Datum'] + ' ' + df['Cas'], dayfirst=True)
    # Tisk pro kontrolu, že Data úspěšně načtena z CSV
    print("Data úspěšně načtena z CSV.")
# Pokud soubor chybí nebo má špatný formát, napíše Chyba při čtení CSV a ukončí skript    
except Exception as e:
    print(f"Chyba při čtení CSV: {e}")
    exit(1)

#2. ČÁST: Připojení k databázi (Load)
# Připojení k MariaDB kontejneru, musí se shodovat s docker-compose.yml
USER = "myuser"
PASSWORD = "my-secret-pw"
HOST = "db_server"  # Musí se shodovat s názvem služby v docker-compose
PORT = "3306"
DATABASE = "testdb"

# "motor/engine" pro komunikaci, ovladač 'pymysql'.
# Formát adresy: mysql+pymysql://uživatel:heslo@server:port/databáze
engine = create_engine(f"mysql+pymysql://{USER}:{PASSWORD}@{HOST}:{PORT}/{DATABASE}")

# Zkusí se připojit 5x
print("Navazuji spojení s databází...")
connected = False
for i in range(5):
    try:
        # Testovací pokus o reálné spojení
        with engine.connect() as conn:
            print("Spojení s databází úspěšně navázáno!")
            connected = True
            break
    except Exception:
        print(f"Databáze na '{HOST}' zatím není ready, zkusím znovu za 5 sekund... ({i+1}/5)")
        time.sleep(5)

if not connected:
    print("CHYBA: Nepodařilo se připojit k databázi ani po 5 pokusech.")
    exit(1)


# Samotný zápis do DB, Vybere jen ty sloupce, které chceme skutečně uložit do databáze, v V5 a V6 josu nuly, bylo od startu PLC nefunkční měření/snímače PT100
cols_for_db = ['Timestamp', 'V1', 'V2', 'V3', 'V4']
try:
    # Zapíše data do tabulky 'senzory_data', Pokud tabulka existuje, smaže ji a vytvoří novou
    # index=True -> Ukládá pořadové číslo řádku jako samostatný sloupec
    df[cols_for_db].to_sql('senzory_data', con=engine, if_exists='replace', index=True)
    print("Úspěšně uloženo do samostatného MariaDB kontejneru!") # Napíše pro kontrolu "Úspěšně uloženo do samostatného MariaDB kontejneru!"
except Exception as e:
    # Chyba/vyjímka - např. špatné heslo, nedostupná síť, plná databáze a napíše Chyba při zápisu do DB
    print(f"Chyba při zápisu do DB: {e}")